Leonardo Hand Forward
A font inspired by the codex of Leonardo Da Vinci. He wrote backwards in a handwriting similar to this. This version is left-right.
Contact: typo969@gmail.com
Web: http://fonts.typo969.net

The personal, non-commercial use of my font is free.
But Donations are accepted and highly appreciated!
The use of my fonts for commercial and profit purposes is acceptable, but you must pay a one time fee of $30 which is non-distributable across computers.
These font files may not be modified and this readme file must be 
included with each font.

All trademarks are property of their respective owners.